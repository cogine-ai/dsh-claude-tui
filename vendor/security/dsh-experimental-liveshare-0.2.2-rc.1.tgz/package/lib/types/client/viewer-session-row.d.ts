/**
 * The viewer page's branch lineage markers.
 *
 * The viewer renders the normal sidebar. Its Session menu actions belong to
 * ui-workspace and follow the page's endpoint access snapshot. Branch creation
 * uses the Workspace navigation service's reader path, without a title write
 * the reader does not hold, and opens the child once the Host lists it.
 *
 * The Liveshare client face mounts this module only on a viewer page.
 * @module @deepseek-ai/dsh-experimental-liveshare/src/client/viewer-session-row
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
export declare const name = "liveshare-viewer-session-row";
/** The slot ledger and locale seat used by branch lineage markers. */
export declare const inject: readonly string[];
/**
 * Register the viewer's branch lineage marker.
 * @param ctx - browser context of the viewer's module table.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=viewer-session-row.d.ts.map