/**
 * Host method-level access control. The Gateway asks `decide()` before it
 * dispatches a non-owner call or forwards an event to a non-owner Peer; list
 * methods filter items through `allows()`; every Peer reads its own access
 * snapshot, first from the index and then from `follow()`. Business packages
 * register one policy per non-owner principal kind.
 * @module @deepseek-ai/dsh-api-remote-access
 */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService, type Principal, type PrincipalMap, type RemoteAccessResource } from '@deepseek-ai/dsh-typert-protocol';
import type { RemoteAccessDecision, RemoteAccessFrame, RemoteAccessPolicy, RemoteAccessRequest } from './types.ts';
export type * from './types.ts';
export { REMOTE_ACCESS_SNAPSHOT_KEY } from './snapshot.ts';
/** The opening frame of a snapshot generation. */
export type RemoteAccessBaseline = Extract<RemoteAccessFrame, {
    type: 'baseline';
}>;
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Host method-level access control for non-owner Peers. */
        remoteAccess: RemoteAccessService;
    }
}
/**
 * Registry of access policies, the Gateway's access decisions, list
 * filtering, and the per-Peer access snapshot. Every composition that mounts
 * the Gateway mounts this service too.
 */
export declare class RemoteAccessService extends TypertRemoteService {
    private readonly policies;
    /** Policies whose failure was logged since the last `invalidate()`; their later failures stay silent. */
    private readonly reported;
    private readonly followers;
    /** Aborted when this instance unloads; every open snapshot generation ends with it. */
    private readonly lifetime;
    /** @param ctx - owning Host plugin Context. */
    constructor(ctx: Context);
    /**
     * Register the policy of one non-owner principal kind in the caller's
     * fiber; open snapshots are recomputed on registration and removal.
     * @param kind - the principal kind the policy serves; never `owner`.
     * @param policy - business-owned bindings and refusal reasons for principals of `kind`.
     * @returns disposer removing this policy.
     * @throws Error when `kind` already has a policy.
     */
    registerPolicy<K extends Exclude<keyof PrincipalMap, 'owner'>>(kind: K, policy: RemoteAccessPolicy<PrincipalMap[K]>): () => void;
    /**
     * Report that the bindings or condition answers for `principal` may have
     * changed. Business packages call this on every grant, revocation, mode
     * change, and expiry; open snapshots re-push, and the next failure of each
     * policy is logged again.
     * @param principal - affected principal; omitted for every principal.
     */
    invalidate(principal?: Principal): void;
    /**
     * Gateway-only: decide one request whose resources the Gateway resolved.
     * The owner is allowed, and so is `remoteAccess/follow`: every Peer reads
     * its own snapshot. Otherwise the action is allowed only when, on every
     * listed resource, some binding of the principal's policy names that
     * resource, has a role listing the action, and has no condition or a
     * condition that allows. `bindings()` is called once per decision.
     * @param request - the caller or recipient, the action, the resources it
     *   touches, and a call's arguments.
     * @returns `allow`; or `deny` with `no-allow` when the principal kind has
     *   no policy, the first refusing condition's reason on the first resource
     *   no binding allows, else `explain()`'s reason, else `no-allow`;
     *   `policy-failed` when `bindings()`, a condition, or `explain()` throws,
     *   logged once per policy until the next `invalidate()`. The Gateway
     *   throws `remote-access/denied` for a denied call and drops a denied event.
     */
    decide(request: RemoteAccessRequest<Principal>): RemoteAccessDecision;
    /**
     * Filter items inside a Remote method. The invocation is read from the
     * Context that accessed this service, so call it as
     * `this.ctx.remoteAccess.allows(resource)` from the Remote method. Each
     * check reads the policy's bindings again, so a long-running stream sees
     * binding changes from the next check on.
     * @param resource - resource of one result item.
     * @returns true for the owner and outside a Remote call; otherwise whether
     *   the invocation's endpoint action is allowed on `resource` without call
     *   arguments, false when the policy is absent or fails.
     */
    allows(resource: RemoteAccessResource): boolean;
    /**
     * The baseline a page opens with before its snapshot stream connects; every
     * index the webServer renders carries it under
     * {@link REMOTE_ACCESS_SNAPSHOT_KEY} for the Peer the page speaks for.
     * @param principal - the page's caller identity.
     * @returns the owner baseline for the owner; otherwise the principal's current grants.
     */
    snapshotFor(principal: Principal): RemoteAccessBaseline;
    /**
     * Stream the calling Peer's access snapshot: one baseline, then `upsert`
     * and `remove` frames after each `invalidate()` and each policy
     * registration or removal that changes a grant. The owner receives only
     * `{ owner: true }`. The generation ends when `signal` aborts or this
     * service unloads, so a reloaded service starts every reader from a fresh
     * baseline.
     * @param signal - generation cancellation.
     * @returns the access frames of one generation.
     */
    follow(signal: AbortSignal): AsyncIterable<RemoteAccessFrame>;
    /** One `bindings()` call; `undefined` after a logged failure. */
    private bindingsOf;
    /** Find a binding on `resource` whose role lists `action` and whose condition, if any, allows. */
    private evaluate;
    /** The refusal reason `explain()` names, else `no-allow`; `policy-failed` when it throws. */
    private explain;
    /**
     * One grant per bound resource, in first-binding order: the endpoint
     * actions of the resource's bindings that `decide()` would allow there
     * without call arguments. A resource with no such action gets no grant;
     * event actions stay out of the snapshot.
     */
    private grantsFor;
    /** Log a policy failure once per policy until the next `invalidate()`; snapshots and lists ask many times per change. */
    private report;
}
export default RemoteAccessService;
//# sourceMappingURL=index.d.ts.map